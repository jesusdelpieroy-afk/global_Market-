// Catálogo inicial de Global Market (datos de prueba).
// A partir de aquí se genera database/seed.sql  ->  node database/build-seed.js
// Cada grupo usa una de las fotos de /public/img/products. Las variantes cambian medida, capacidad o pack.

const categories = ["Hogar", "Organizadores", "Accesorios de cabello", "Cocina", "Baño", "Limpieza", "Bebé", "Dormitorio", "Alfombras"];

// Los 4 productos originales (sin foto: usan el logo hasta que el encargado suba una)
const original = [
  { id: "p1", name: "Canasta organizadora con tapa", price: 24.9, category: "Organizadores", desc: "Ideal para ordenar ropa, juguetes o utensilios.", image: "", stock: 12 },
  { id: "p2", name: "Cesto de ropa tejido", price: 39.9, category: "Hogar", desc: "Cesto ventilado, resistente y fácil de limpiar.", image: "", stock: 8 },
  { id: "p3", name: "Set de scrunchies de colores", price: 9.9, category: "Accesorios de cabello", desc: "Pack de colores variados, suaves con el cabello.", image: "", stock: 30 },
  { id: "p4", name: "Diadema de spa", price: 7.5, category: "Accesorios de cabello", desc: "Para el cuidado facial y el maquillaje.", image: "", stock: 4 }
];

// [nombre, precio S/, detalle]
const groups = [
  { img: "plato", cat: "Cocina", base: "Plato negro mate de superficie lisa, apto para uso diario.", items: [
    ["Plato hondo negro 20 cm", 6.9, "Ideal para sopas, cereales y postres."],
    ["Plato hondo negro 23 cm", 8.9, "El tamaño más versátil para el día a día."],
    ["Plato hondo negro 26 cm", 11.9, "Porciones generosas de guisos y ensaladas."],
    ["Plato de pasta negro 28 cm", 13.9, "Borde amplio para pastas y platos de fondo."],
    ["Set de 4 platos hondos negros 23 cm", 32.9, "Juego listo para la mesa de la familia."],
    ["Set de 6 platos hondos negros 23 cm", 46.9, "Juego completo, ideal para reuniones."] ] },
  { img: "tacho", cat: "Hogar", base: "Tacho gris con tapa vaivén que mantiene los olores adentro.", items: [
    ["Tacho con tapa vaivén 5 L", 12.9, "Compacto, para baño o escritorio."],
    ["Tacho con tapa vaivén 10 L", 17.9, "Perfecto para la cocina o el dormitorio."],
    ["Tacho con tapa vaivén 15 L", 22.9, "Capacidad media para el hogar."],
    ["Tacho con tapa vaivén 25 L", 29.9, "Para cocina y áreas de mayor uso."],
    ["Tacho con tapa vaivén 40 L", 39.9, "Gran capacidad para oficina o negocio."],
    ["Pack 2 tachos con tapa vaivén 10 L", 32.9, "Uno para cada ambiente, a mejor precio."] ] },
  { img: "botellas", cat: "Cocina", base: "Botella deportiva de plástico resistente con tapa de boquilla.", items: [
    ["Botella deportiva 500 ml", 8.9, "Liviana, cabe en la mochila o el auto."],
    ["Botella deportiva 750 ml", 11.9, "Para gimnasio, colegio y paseos."],
    ["Botella deportiva 1 litro", 14.9, "Hidratación para toda la jornada."],
    ["Botella deportiva 1.5 litros", 18.9, "Gran capacidad para entrenar o trabajar."],
    ["Set de 2 botellas deportivas 500 ml", 15.9, "Dos botellas para compartir."],
    ["Set de 3 botellas deportivas 750 ml", 31.9, "Para toda la familia."] ] },
  { img: "canasta", cat: "Organizadores", base: "Canasta calada de plástico rojo, ventilada y fácil de lavar.", items: [
    ["Canasta calada roja 15 L", 9.9, "Pequeña, para accesorios y utensilios."],
    ["Canasta calada roja 25 L", 14.9, "Ordena juguetes, ropa o verduras."],
    ["Canasta calada roja 35 L", 19.9, "Ideal para el cuarto de lavado."],
    ["Canasta calada roja 45 L", 24.9, "Gran tamaño para ropa o compras."],
    ["Canasta para ropa sucia roja 60 L", 29.9, "La más grande, con asas laterales."],
    ["Set de 3 canastas caladas rojas", 39.9, "Tres tamaños para organizar toda la casa."] ] },
  { img: "jarra", cat: "Cocina", base: "Jarra transparente con tapa de color y pico vertedor.", items: [
    ["Jarra con tapa 1 litro", 9.9, "Para jugos y agua en el día a día."],
    ["Jarra con tapa 1.5 litros", 12.9, "Tamaño ideal para la mesa familiar."],
    ["Jarra con tapa 2 litros", 14.9, "La más pedida, apta para bebidas frías."],
    ["Jarra con tapa 2.5 litros", 17.9, "Para reuniones y almuerzos."],
    ["Jarra con tapa 3 litros", 21.9, "Gran capacidad para fiestas."],
    ["Set de 2 jarras con tapa 2 litros", 27.9, "Dos jarras, a mejor precio."] ] },
  { img: "sarten", cat: "Cocina", base: "Sartén antiadherente negra con mango ergonómico.", items: [
    ["Sartén antiadherente 20 cm", 19.9, "Para huevos, tortillas y porciones pequeñas."],
    ["Sartén antiadherente 22 cm", 22.9, "Ideal para cocinar para una o dos personas."],
    ["Sartén antiadherente 24 cm", 26.9, "El tamaño más usado en casa."],
    ["Sartén antiadherente 26 cm", 31.9, "Para saltados y platos de fondo."],
    ["Sartén antiadherente 28 cm", 36.9, "Gran superficie para familias."],
    ["Sartén antiadherente 30 cm", 42.9, "Para cocinar en cantidad."] ] },
  { img: "zapatero-a", cat: "Organizadores", base: "Zapatero metálico de 5 niveles, fácil de armar sin herramientas.", items: [
    ["Zapatero metálico 5 niveles 10 pares", 49.9, "Estructura liviana y resistente."],
    ["Zapatero metálico 5 niveles 15 pares", 59.9, "Más espacio por nivel para toda la familia."],
    ["Zapatero metálico 5 niveles reforzado", 69.9, "Postes reforzados para mayor estabilidad."],
    ["Combo 2 zapateros metálicos 5 niveles", 99.9, "Para recibidor o vestidor grande."] ] },
  { img: "perchero", cat: "Organizadores", base: "Perchero metálico de doble barra con repisa inferior y ruedas.", items: [
    ["Perchero doble barra con ruedas 100 cm", 79.9, "Compacto, para dormitorios pequeños."],
    ["Perchero doble barra con ruedas 120 cm", 94.9, "Ideal para ropa de toda la semana."],
    ["Perchero doble barra con ruedas 150 cm", 119.9, "Máxima capacidad para tu ropa."],
    ["Perchero doble barra reforzado", 129.9, "Tubos más gruesos para prendas pesadas."],
    ["Perchero con repisa para zapatos", 99.9, "Cuelga la ropa y guarda calzado abajo."],
    ["Perchero móvil para tienda o closet", 109.9, "Se mueve fácil gracias a sus ruedas."] ] },
  { img: "zapatero-b", cat: "Organizadores", base: "Zapatero de 5 niveles con estructura blanca y negra.", items: [
    ["Zapatero 5 niveles blanco y negro", 44.9, "Diseño moderno que combina con todo."],
    ["Zapatero compacto 5 niveles 60 cm", 39.9, "Para espacios reducidos."],
    ["Zapatero 5 niveles 75 cm", 54.9, "Más ancho, más pares."],
    ["Pack 2 zapateros 5 niveles", 79.9, "Dos zapateros al mejor precio."] ] },
  { img: "alfombra-antideslizante", cat: "Baño", base: "Alfombra de PVC translúcido con ventosas que evitan resbalones.", items: [
    ["Alfombra antideslizante 40 x 60 cm", 14.9, "Medida estándar para la ducha."],
    ["Alfombra antideslizante 40 x 70 cm", 17.9, "Con ventosas de alta adherencia."],
    ["Alfombra antideslizante 50 x 80 cm", 21.9, "Más cobertura para la tina o ducha."],
    ["Alfombra antideslizante 60 x 90 cm", 27.9, "Gran tamaño, se lava y seca rápido."],
    ["Set de 2 alfombras antideslizantes 40 x 60 cm", 26.9, "Una para la ducha y otra para el baño."] ] },
  { img: "cubrecama", cat: "Dormitorio", base: "Cubrecama acolchado gris, suave y liviano, con costuras en rombos.", items: [
    ["Cubrecama acolchado gris 1 plaza", 59.9, "Para camas individuales."],
    ["Cubrecama acolchado gris 1.5 plazas", 69.9, "Ideal para camas medianas."],
    ["Cubrecama acolchado gris 2 plazas", 79.9, "El más vendido para matrimonial."],
    ["Cubrecama acolchado gris Queen", 94.9, "Cobertura generosa para cama Queen."],
    ["Cubrecama acolchado gris King", 109.9, "Para cama King, con caída amplia."],
    ["Pack 2 cubrecamas acolchados grises 1 plaza", 109.9, "Ideal para habitaciones compartidas."] ] },
  { img: "toallitas-pequenin", cat: "Bebé", base: "Toallitas húmedas Pequeñín con almendra, sin alcohol, con tapa reutilizable.", items: [
    ["Toallitas húmedas Pequeñín almendra x100", 9.9, "Limpian e hidratan la piel del bebé."],
    ["Pack 2 toallitas húmedas Pequeñín almendra x100", 18.9, "200 toallitas para todo el mes."],
    ["Pack 3 toallitas húmedas Pequeñín almendra x100", 27.5, "300 toallitas a mejor precio."],
    ["Pack 6 toallitas húmedas Pequeñín almendra x100", 53.9, "Ahorra comprando por mayor."],
    ["Caja 12 toallitas húmedas Pequeñín almendra x100", 104.9, "Caja cerrada, ideal para guarderías."] ] },
  { img: "toallitas-tuinies", cat: "Bebé", base: "Toallitas húmedas Tuinies extrasuaves, diseño Hello Kitty, con tapa.", items: [
    ["Toallitas húmedas Tuinies Hello Kitty x100", 8.9, "Extrasuaves, con estampado Hello Kitty."],
    ["Pack 2 toallitas húmedas Tuinies Hello Kitty x100", 16.9, "200 toallitas, ideal para la pañalera."],
    ["Pack 3 toallitas húmedas Tuinies Hello Kitty x100", 24.5, "Mejor precio por unidad."],
    ["Pack 6 toallitas húmedas Tuinies Hello Kitty x100", 47.9, "Para tener en casa todo el mes."],
    ["Caja 12 toallitas húmedas Tuinies Hello Kitty x100", 92.9, "Caja cerrada para mayor ahorro."] ] },
  { img: "fibra", cat: "Limpieza", base: "Fibra verde Scotch-Brite de limpieza profunda para la cocina.", items: [
    ["Fibra Scotch-Brite cocina x1", 2.5, "Dura más y limpia mejor."],
    ["Fibra Scotch-Brite cocina x2", 4.5, "Pack ahorro para el lavadero."],
    ["Fibra Scotch-Brite cocina x3", 6.5, "Para ollas, sartenes y parrillas."],
    ["Fibra Scotch-Brite cocina x6", 12.5, "Pack familiar."],
    ["Fibra Scotch-Brite cocina x12", 23.9, "Ideal para restaurantes y negocios."],
    ["Caja fibra Scotch-Brite cocina x24", 44.9, "Precio por mayor."] ] },
  { img: "alfombra-chenille", cat: "Baño", base: "Alfombra de chenille gris, muy absorbente y suave al pisar.", items: [
    ["Alfombra de baño chenille gris 40 x 60 cm", 19.9, "Absorbe el agua al salir de la ducha."],
    ["Alfombra de baño chenille gris 45 x 75 cm", 24.9, "Tamaño mediano para frente al lavatorio."],
    ["Alfombra de baño chenille gris 50 x 80 cm", 27.9, "Suave y de secado rápido."],
    ["Alfombra de baño chenille gris 60 x 90 cm", 34.9, "Gran superficie para el baño principal."],
    ["Set de 2 alfombras chenille grises", 42.9, "Dos medidas para ducha y lavatorio."],
    ["Set de 3 alfombras chenille grises", 59.9, "Juego completo para el baño."] ] },
  { img: "tapete-fibra", cat: "Alfombras", base: "Tapete tejido de fibra natural con borde reforzado.", items: [
    ["Tapete de fibra natural 40 x 60 cm", 24.9, "Perfecto como entrada a la puerta."],
    ["Tapete de fibra natural 50 x 70 cm", 32.9, "Para recibidor o cocina."],
    ["Tapete de fibra natural 60 x 90 cm", 44.9, "Resistente, de estilo rústico."],
    ["Tapete de fibra natural 80 x 120 cm", 79.9, "Para pasillos y salas pequeñas."],
    ["Tapete de fibra natural 120 x 170 cm", 149.9, "Para sala o comedor."] ] },
  { img: "alfombra-shaggy", cat: "Alfombras", base: "Alfombra shaggy beige de pelo largo, muy suave y cálida.", items: [
    ["Alfombra shaggy beige 50 x 80 cm", 29.9, "Para el borde de la cama o el baño."],
    ["Alfombra shaggy beige 60 x 90 cm", 39.9, "Suave y fácil de combinar."],
    ["Alfombra shaggy beige 80 x 150 cm", 69.9, "Ideal para pasillos y dormitorios."],
    ["Alfombra shaggy beige 120 x 170 cm", 119.9, "Para sala pequeña o dormitorio."],
    ["Alfombra shaggy beige 160 x 230 cm", 199.9, "Gran tamaño para la sala."],
    ["Alfombra shaggy beige 200 x 290 cm", 299.9, "Para ambientes amplios."] ] },
  { img: "taza", cat: "Cocina", base: "Taza de cerámica artesanal en verde agua y terracota, acabado esmaltado.", items: [
    ["Taza de cerámica artesanal 250 ml", 14.9, "Perfecta para café o té."],
    ["Taza de cerámica artesanal 300 ml", 16.9, "Asa cómoda y base estable."],
    ["Taza de cerámica artesanal 400 ml", 19.9, "Tamaño grande para el desayuno."],
    ["Set de 2 tazas de cerámica artesanal", 27.9, "Para compartir un café."],
    ["Set de 4 tazas de cerámica artesanal", 52.9, "Juego para la familia."],
    ["Set de 6 tazas de cerámica artesanal", 76.9, "Ideal para regalo o reuniones."] ] }
];

// Stock de ejemplo, repetible (con unos pocos productos con poco stock y uno agotado para probar los avisos)
function stockFor(n) {
  if (n === 37) return 0;
  const v = (n * 7 + 3) % 29;
  return v < 3 ? v + 2 : v + 4;
}

const generated = [];
let n = 5;
groups.forEach(g => g.items.forEach(([name, price, detail]) => {
  generated.push({ id: "p" + n, name, price, category: g.cat, desc: `${g.base} ${detail}`, image: `img/products/${g.img}.jpg`, stock: stockFor(n) });
  n++;
}));

module.exports = { categories, products: original.concat(generated) };
