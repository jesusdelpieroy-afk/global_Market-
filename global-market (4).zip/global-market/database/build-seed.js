// Genera database/seed.sql a partir de database/catalog.js
//   node database/build-seed.js
const fs = require("fs");
const path = require("path");
const { categories, products } = require("./catalog");
const { hashPassword } = require("../server/auth");

const q = s => "'" + String(s).replace(/'/g, "''") + "'";
const faqs = [
  { q: "¿Cómo hago mi pedido?", a: "Agrega los productos al carrito y presiona «Enviar pedido por WhatsApp». Te confirmamos la disponibilidad y coordinamos contigo el pago y la entrega." },
  { q: "¿Qué medios de pago aceptan?", a: "El pago se coordina por WhatsApp una vez confirmado tu pedido. Escríbenos y te indicamos las opciones disponibles." },
  { q: "¿Hacen envíos?", a: "La entrega se coordina contigo por WhatsApp según tu zona." },
  { q: "¿Los productos tienen stock?", a: "El catálogo muestra el stock disponible de cada producto. Si algo aparece agotado, escríbenos y te avisamos cuando vuelva a haber." }
];
const settings = {
  name: "Global Market", tagline: "Hogar, organizadores y accesorios", whatsapp: "51999999999", currency: "S/",
  heroTitle: "Todo para tu hogar en un solo lugar",
  heroText: "Elige lo que necesitas del catálogo y haz tu pedido por WhatsApp. Confirmamos la disponibilidad y coordinamos el pago y la entrega contigo.",
  heroImage1: "", heroImage2: "", address: "", hours: "", faqs: JSON.stringify(faqs), data_version: "1"
};

let sql = "-- Global Market — datos iniciales (generado con: node database/build-seed.js)\n-- Incluye 104 productos de prueba, categorías, una promoción y la cuenta del encargado.\n\nPRAGMA foreign_keys = ON;\nBEGIN;\n\n";
sql += "-- Ajustes de la tienda\n";
Object.entries(settings).forEach(([k, v]) => { sql += `INSERT OR IGNORE INTO settings (key, value) VALUES (${q(k)}, ${q(v)});\n`; });

sql += "\n-- Cuenta del encargado de prueba:  admin@globalmarket.com  /  123456  (cámbiala al entrar)\n";
sql += `INSERT OR IGNORE INTO admin_user (id, email, password_hash, must_change) VALUES (1, 'admin@globalmarket.com', ${q(hashPassword("123456"))}, 1);\n`;

sql += "\n-- Categorías\n";
categories.forEach((c, i) => { sql += `INSERT OR IGNORE INTO categories (name, sort_order) VALUES (${q(c)}, ${i});\n`; });

sql += "\n-- Productos\n";
products.forEach((p, i) => {
  sql += `INSERT OR IGNORE INTO products (id, name, price, category_id, description, image, stock, sort_order) VALUES (${q(p.id)}, ${q(p.name)}, ${p.price}, (SELECT id FROM categories WHERE name = ${q(p.category)}), ${q(p.desc)}, ${q(p.image)}, ${p.stock}, ${i});\n`;
});

sql += "\n-- Promoción de bienvenida (10% a toda la tienda)\n";
sql += "INSERT OR IGNORE INTO promos (id, title, description, percent, all_products, until, image, active, sort_order) VALUES ('pr1', 'Oferta de bienvenida', '10% de descuento en todos los productos de la tienda.', 10, 1, '', '', 1, 0);\n";
sql += "\nCOMMIT;\n";

fs.writeFileSync(path.join(__dirname, "seed.sql"), sql);
console.log(`seed.sql generado: ${products.length} productos, ${categories.length} categorías.`);
