-- Global Market — esquema de la base de datos (SQLite)
-- Se ejecuta automáticamente al iniciar el servidor si la base está vacía,
-- o a mano con:  npm run db:init

PRAGMA foreign_keys = ON;

-- Datos de la tienda (nombre, WhatsApp, portada, preguntas frecuentes, versión de datos...)
CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT ''
);

-- Cuenta del encargado (una sola). La contraseña se guarda con hash scrypt, nunca en texto plano.
CREATE TABLE IF NOT EXISTS admin_user (
  id            INTEGER PRIMARY KEY CHECK (id = 1),
  email         TEXT    NOT NULL,
  password_hash TEXT    NOT NULL,
  must_change   INTEGER NOT NULL DEFAULT 1,   -- 1 = todavía usa la contraseña inicial
  updated_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS categories (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT    NOT NULL UNIQUE COLLATE NOCASE,
  sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS products (
  id          TEXT    PRIMARY KEY,
  name        TEXT    NOT NULL,
  price       REAL    NOT NULL DEFAULT 0 CHECK (price >= 0),
  category_id INTEGER NOT NULL REFERENCES categories(id) ON UPDATE CASCADE ON DELETE RESTRICT,
  description TEXT    NOT NULL DEFAULT '',
  image       TEXT    NOT NULL DEFAULT '',    -- ruta relativa: img/products/x.jpg o uploads/x.jpg
  stock       INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_sort     ON products(sort_order);

CREATE TABLE IF NOT EXISTS promos (
  id           TEXT    PRIMARY KEY,
  title        TEXT    NOT NULL,
  description  TEXT    NOT NULL DEFAULT '',
  percent      INTEGER NOT NULL CHECK (percent BETWEEN 1 AND 90),
  all_products INTEGER NOT NULL DEFAULT 1,
  until        TEXT    NOT NULL DEFAULT '',   -- AAAA-MM-DD (vacío = sin fecha)
  image        TEXT    NOT NULL DEFAULT '',
  active       INTEGER NOT NULL DEFAULT 1,
  sort_order   INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS promo_products (
  promo_id   TEXT NOT NULL REFERENCES promos(id)   ON DELETE CASCADE,
  product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  PRIMARY KEY (promo_id, product_id)
);
