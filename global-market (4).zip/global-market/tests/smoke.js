// Prueba de humo de la API: usa una base de datos temporal, no toca tus datos.
//   npm test
const os = require("os"), fs = require("fs"), path = require("path"), assert = require("assert");
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), "gm-test-"));
const app = require("../server/index.js");

const PNG = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==";
let cookie = "";
const server = app.listen(0, async () => {
  const base = "http://127.0.0.1:" + server.address().port;
  const call = async (method, url, body) => {
    const r = await fetch(base + url, { method, headers: { "Content-Type": "application/json", cookie }, body: body === undefined ? undefined : JSON.stringify(body) });
    const sc = r.headers.get("set-cookie"); if (sc) cookie = sc.split(";")[0];
    let j = null; try { j = await r.json(); } catch (e) {}
    return { status: r.status, body: j };
  };
  let n = 0; const ok = (name) => console.log(`  ✓ ${++n}. ${name}`);
  try {
    let r = await call("GET", "/api/public");
    assert.equal(r.body.products.length, 104); assert.ok(!("email" in r.body.config)); ok("catálogo público con 104 productos y sin datos privados");
    assert.equal((await call("GET", "/api/admin/data")).status, 401); ok("el panel exige sesión");
    assert.equal((await call("POST", "/api/login", { email: "admin@globalmarket.com", password: "mala" })).status, 401); ok("rechaza contraseña incorrecta");
    r = await call("POST", "/api/login", { email: "ADMIN@globalmarket.com", password: "123456" }); assert.equal(r.status, 200); ok("login correcto");

    const v0 = (await call("GET", "/api/version")).body.version;
    r = await call("POST", "/api/admin/products", { name: "Producto de prueba", price: 12.5, category: "Hogar", desc: "x", stock: 3, image: PNG });
    assert.equal(r.status, 201); const p = r.body.products[0]; assert.equal(p.name, "Producto de prueba"); assert.match(p.image, /^uploads\/[a-f0-9]+\.png$/);
    assert.ok(fs.existsSync(path.join(process.env.DATA_DIR, p.image))); ok("crea producto y guarda la foto");
    assert.ok(r.body.version > v0);
    assert.equal((await call("GET", "/api/public")).body.products[0].id, p.id); ok("el visitante ve el producto nuevo al instante");

    r = await call("PUT", "/api/admin/products/" + p.id, { name: "Editado", price: 20, category: "Cocina", desc: "y", stock: 9 });
    assert.equal(r.body.products[0].name, "Editado"); assert.equal(r.body.products[0].category, "Cocina"); assert.equal(r.body.products[0].image, p.image); ok("edita producto conservando la foto");
    r = await call("PATCH", "/api/admin/products/" + p.id + "/stock", { stock: 0 }); assert.equal(r.body.products[0].stock, 0); ok("actualiza stock");
    assert.equal((await call("POST", "/api/admin/products", { name: "", price: 1, category: "Hogar" })).status, 400); ok("valida datos del producto");
    assert.equal((await call("POST", "/api/admin/products", { name: "x", price: 1, category: "NoExiste" })).status, 400); ok("valida la categoría");

    r = await call("POST", "/api/admin/promos", { title: "Promo X", percent: 25, all: false, productIds: [p.id], until: "", active: true });
    assert.equal(r.status, 201); const pr = r.body.promos[0]; assert.deepEqual(pr.productIds, [p.id]); ok("crea promoción para un producto");
    r = await call("PATCH", "/api/admin/promos/" + pr.id + "/toggle"); assert.equal(r.body.promos[0].active, false);
    assert.ok(!(await call("GET", "/api/public")).body.promos.some(x => x.id === pr.id)); ok("una promoción pausada no se ve en la tienda");

    r = await call("POST", "/api/admin/categories", { name: "Juguetes" }); assert.ok(r.body.categories.includes("Juguetes"));
    r = await call("PUT", "/api/admin/categories", { from: "Juguetes", to: "Juegos" }); assert.ok(r.body.categories.includes("Juegos"));
    assert.equal((await call("DELETE", "/api/admin/categories?name=Cocina")).status, 409);
    r = await call("DELETE", "/api/admin/categories?name=Juegos"); assert.ok(!r.body.categories.includes("Juegos")); ok("crea, renombra y elimina categorías (protege las que tienen productos)");

    r = await call("PUT", "/api/admin/config", { name: "Mi Tienda", whatsapp: "+51 987 654 321", heroTitle: "Hola", faqs: [{ q: "¿A?", a: "B" }], heroImage1: PNG });
    assert.equal(r.body.config.name, "Mi Tienda"); assert.equal(r.body.config.whatsapp, "51987654321"); assert.match(r.body.config.heroImage1, /^uploads\//);
    assert.equal((await call("GET", "/api/public")).body.config.faqs.length, 1); ok("guarda datos de la tienda y portada");

    r = await call("DELETE", "/api/admin/products/" + p.id); assert.ok(!r.body.products.some(x => x.id === p.id));
    assert.ok(!r.body.promos.find(x => x.id === pr.id).productIds.length); ok("elimina producto (y lo quita de las promociones)");

    const bk = await call("GET", "/api/admin/export"); assert.equal(bk.body.products.length, 104);
    assert.equal((await call("POST", "/api/admin/import", bk.body)).body.products.length, 104); ok("exporta e importa copia de seguridad");

    assert.equal((await call("PUT", "/api/admin/account", { email: "otro@correo.com", password: "123" })).status, 400);
    r = await call("PUT", "/api/admin/account", { email: "nuevo@correo.com", password: "clave-nueva" }); assert.equal(r.status, 200); assert.equal(r.body.config.passwordSet, true);
    assert.equal((await call("GET", "/api/admin/data")).status, 200); ok("cambia correo y contraseña (la sesión sigue activa)");
    cookie = ""; assert.equal((await call("POST", "/api/login", { email: "admin@globalmarket.com", password: "123456" })).status, 401);
    assert.equal((await call("POST", "/api/login", { email: "nuevo@correo.com", password: "clave-nueva" })).status, 200); ok("la contraseña anterior deja de funcionar");

    const html = await (await fetch(base + "/")).text(); assert.ok(html.includes("window.__GM_DATA__") && html.includes('"@type":"ItemList"')); ok("la portada trae los datos y SEO de productos");
    const f = await fetch(base + "/api/admin/products", { method: "POST", headers: { "Content-Type": "text/plain", cookie }, body: "{}" }); assert.equal(f.status, 415); ok("bloquea peticiones que no son JSON");
    console.log("\nTodo correcto ✔"); server.close(); process.exit(0);
  } catch (e) { console.error("\n✘ Falló:", e.message); server.close(); process.exit(1); }
});
