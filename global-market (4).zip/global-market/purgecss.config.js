// Configuración de PurgeCSS: lee tus HTML y JS y deja solo las clases que usas.
// Las clases que Bootstrap agrega con JavaScript (modal, offcanvas, etc.) van en "safelist".
module.exports = {
  content: ["public/index.html", "public/admin.html", "public/js/data.js", "public/js/store.js", "public/js/admin.js"],
  css: ["public/css/custom.css"],
  output: "public/css/reducido.css",
  safelist: {
    standard: ["show", "fade", "collapsing", "modal-open", "offcanvas-backdrop"],
    greedy: [/^modal/, /^offcanvas/, /^dropdown/, /^fade/, /^show/, /^collapse/, /^btn-close/, /^is-/, /^was-/, /^bi-/, /^bi$/]
  }
};
