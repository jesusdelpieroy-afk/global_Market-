# Global Market

Tienda online con **panel del encargado**, **API** y **base de datos**. Lo que el encargado cambia en el panel
(productos, stock, precios, promociones, categorías, portada, datos de la tienda) se guarda en el servidor y
**lo ven al instante todas las personas que entren a la página**, desde cualquier celular o computadora.

- **Frontend:** HTML + Bootstrap 5 (Sass) + JavaScript, con efecto 3D en los productos y asistente virtual.
- **Backend:** Node.js + Express (API REST + actualizaciones en vivo por SSE).
- **Base de datos:** SQLite (un solo archivo, sin instalar nada más).
- **Catálogo de prueba:** 104 productos con fotos, 9 categorías y 1 promoción.

---

## 1. Estructura del proyecto

```
global-market/
├── server/
│   ├── index.js          Servidor Express: API, páginas, SEO (sitemap/robots), tiempo real
│   ├── db.js             Conexión SQLite, consultas y manejo de imágenes subidas
│   ├── auth.js           Contraseñas (scrypt) y sesiones firmadas
│   └── cli.js            Comandos: db:init, db:reset, admin:reset
├── database/
│   ├── schema.sql        Tablas de la base de datos
│   ├── seed.sql          Datos de prueba (104 productos, categorías, promo, cuenta del encargado)
│   ├── catalog.js        Catálogo de prueba en JavaScript (fuente de seed.sql)
│   └── build-seed.js     Regenera seed.sql desde catalog.js
├── public/               Lo que ve el navegador
│   ├── index.html        Tienda (clientes)
│   ├── admin.html        Panel del encargado
│   ├── js/               data.js (capa de datos/API), store.js (tienda), admin.js (panel)
│   ├── css/              Estilos compilados (Bootstrap + diseño propio)
│   └── img/              Logo, fotos del local y fotos de productos (img/products)
├── scss/custom.scss      Diseño propio (colores, tipografía, bordes)
├── tests/smoke.js        Pruebas automáticas de la API
├── .env.example          Variables de configuración
├── Dockerfile            Para desplegar con Docker
└── package.json
```

La carpeta `data/` se crea sola al iniciar y contiene la base de datos (`gm.sqlite`) y las fotos que sube el
encargado (`data/uploads/`). **No se sube a GitHub** (está en `.gitignore`).

---

## 2. Requisitos

- **Node.js 18, 20 o 22** (versión LTS recomendada). Descarga: https://nodejs.org
- Nada más: SQLite viene incluido.

## 3. Instalación y ejecución

```bash
npm install        # instala las dependencias
npm start          # inicia el servidor
```

Abre en el navegador:

| Página | Dirección |
|---|---|
| Tienda | http://localhost:3000 |
| Panel del encargado | http://localhost:3000/admin |

La primera vez, el servidor crea la base de datos y carga los datos de prueba automáticamente.
Para desarrollar con reinicio automático: `npm run dev`.

> **Importante:** abre siempre la tienda desde `http://localhost:3000`. Si haces doble clic en `index.html`
> no hay servidor ni base de datos y no verás los productos.

## 4. Acceso al panel (datos de prueba)

| Campo | Valor |
|---|---|
| Correo | `admin@globalmarket.com` |
| Contraseña | `123456` |

Al entrar aparece un aviso para **crear tu propia contraseña** (Ajustes → Cuenta de acceso, mínimo 6 caracteres).
En producción define `ADMIN_EMAIL` y `ADMIN_PASSWORD` antes de iniciar por primera vez (ver sección 5).

Si olvidas la contraseña: `npm run admin:reset` (con `ADMIN_EMAIL`/`ADMIN_PASSWORD` definidos usa esos valores;
si no, vuelve al acceso de prueba). No borra productos.

## 5. Configuración (variables de entorno)

Todas son opcionales. Mira `.env.example`.

| Variable | Para qué sirve | Por defecto |
|---|---|---|
| `PORT` | Puerto del servidor | `3000` |
| `NODE_ENV` | `production` en el servidor real | — |
| `SITE_URL` | URL pública (sitemap, Google, redes sociales) | la del propio pedido |
| `DATA_DIR` | Carpeta de la base de datos y fotos subidas | `./data` |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | Cuenta del encargado al crear la base por primera vez | acceso de prueba |
| `SESSION_SECRET` | Clave para firmar sesiones | se genera sola |

## 6. Qué puede editar el encargado

Todo desde `/admin`, y se refleja de inmediato en la tienda de todos los visitantes:

- **Productos y stock:** crear, editar, eliminar, foto, precio, stock, categoría (el stock se edita directo en la tabla).
- **Promociones:** descuento % a toda la tienda o a productos elegidos, con fecha de vencimiento; pausar/activar.
- **Categorías:** crear, renombrar, eliminar.
- **Portada:** título, texto y las 2 fotos del inicio.
- **Ajustes:** nombre, WhatsApp, moneda, dirección, horario, preguntas frecuentes, correo y contraseña.
- **Copia de seguridad:** exportar e importar todo en un archivo JSON.

**¿Cómo se mantiene actualizado para todos?** Los datos viven en la base del servidor. Cada cambio sube un
número de versión y el servidor avisa a todos los navegadores abiertos (SSE); estos vuelven a pedir los datos
y repintan el catálogo sin recargar. Si la conexión en vivo se corta, cada navegador revisa la versión cada 30
segundos y al volver a la pestaña. Quien abre la página por primera vez recibe los datos ya incluidos en el HTML.
El carrito de cada cliente se guarda solo en su propio navegador.

## 7. Base de datos

Archivo SQLite: `data/gm.sqlite`. Esquema en `database/schema.sql`:

| Tabla | Contenido |
|---|---|
| `settings` | Nombre, WhatsApp, portada, preguntas frecuentes, versión de datos |
| `admin_user` | Cuenta del encargado (contraseña con hash scrypt) |
| `categories` | Categorías |
| `products` | Productos (precio, stock, foto, categoría) |
| `promos` / `promo_products` | Promociones y los productos a los que aplican |

Comandos:

```bash
npm run db:init      # crea tablas y datos de prueba si la base está vacía
npm run db:reset     # BORRA todo y vuelve a cargar los datos de prueba
npm run seed:build   # regenera database/seed.sql desde database/catalog.js
```

También puedes ejecutar los `.sql` a mano con el cliente de SQLite: primero `schema.sql` y luego `seed.sql`.

**Respaldo:** copia la carpeta `data/` completa (base + fotos subidas) o usa Exportar en el panel.

## 8. API (resumen)

- Públicas: `GET /api/public` (catálogo completo) · `GET /api/version` · `GET /api/events` (tiempo real) · `GET /api/health`.
- Sesión: `POST /api/login` · `POST /api/logout` · `GET /api/me`.
- Panel (requieren sesión, prefijo `/api/admin`): `GET /data`, `POST|PUT|DELETE /products[/:id]`,
  `PATCH /products/:id/stock`, `POST|PUT|DELETE /promos[/:id]`, `PATCH /promos/:id/toggle`,
  `POST|PUT|DELETE /categories`, `PUT /config`, `PUT /account`, `GET /export`, `POST /import`.

Seguridad incluida: contraseñas con hash (scrypt), sesión en cookie `HttpOnly`, límite de intentos de ingreso,
validación de datos e imágenes (tipo y tamaño), consultas SQL parametrizadas y textos escapados en pantalla.

## 9. Pruebas

```bash
npm test
```

Ejecuta 20 comprobaciones de la API sobre una base temporal (no toca tus datos).

## 10. Cambiar el diseño

Edita `scss/custom.scss` (colores, tipografía y bordes están arriba) y ejecuta `npm run build:css`.
Si agregas clases nuevas en el HTML/JS, vuelve a ejecutarlo (genera `public/css/reducido.css`).

## 11. Publicarlo en internet (siguiente paso)

Necesitas un hosting que ejecute **Node.js** y tenga **disco persistente** (donde vive `DATA_DIR`), por ejemplo
Render, Railway, Fly.io o un VPS. Puntos clave:

1. Sube el proyecto a GitHub (no se sube `node_modules` ni `data`).
2. Comando de instalación `npm install`, comando de inicio `npm start` (o usa el `Dockerfile`).
3. Define `NODE_ENV=production`, `SITE_URL`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` y monta un disco/volumen en `DATA_DIR`.
4. **Sin disco persistente se pierden los cambios del encargado y las fotos subidas cada vez que el servidor se reinicia.**
5. Para Google: entra a https://search.google.com/search-console, agrega tu URL, envía `https://TU-DOMINIO/sitemap.xml`
   y solicita la indexación. El servidor ya genera `robots.txt`, `sitemap.xml` y datos estructurados (JSON-LD) con
   todos los productos; `/admin` queda oculto para Google.

## 12. Sobre las fotos de los productos

Los 100 productos nuevos usan tus 18 fotos (en `public/img/products/`). Cada foto se reutiliza en las variantes
de medida, capacidad o pack del mismo producto. El encargado puede cambiar la foto de cualquiera desde el panel.
Las fotos de las botellas muestran una marca de ejemplo ("Tu marca aquí / Publiprom"); conviene reemplazarlas por
fotos propias. Los 4 productos originales no tienen foto: muestran el logo hasta que se les suba una.

## 13. Problemas frecuentes

- **No se ven productos:** abre `http://localhost:3000`, no el archivo HTML directo.
- **`npm install` falla en `better-sqlite3`:** usa Node 18/20/22 LTS.
- **Puerto ocupado:** `PORT=3001 npm start`.
- **Los cambios del panel no aparecen en otro dispositivo:** revisa que ambos abran la misma dirección del servidor.
