/* Global Market — capa de datos compartida entre la tienda y el panel.
   Los datos viven en la base de datos del servidor (API /api). Todos los visitantes ven lo mismo
   y se actualizan solos cuando el encargado guarda un cambio (tiempo real con SSE + respaldo por sondeo). */
const GM = (() => {
  const CART_KEY = "gm_cart_v1";
  const CACHE_KEY = "gm_cache_v2";

  // Datos mínimos que se muestran sólo si el servidor no responde y no hay copia previa
  const defaults = {
    config: {
      name: "Global Market", tagline: "Hogar, organizadores y accesorios", whatsapp: "51999999999", currency: "S/",
      heroTitle: "Todo para tu hogar en un solo lugar",
      heroText: "Elige lo que necesitas del catálogo y haz tu pedido por WhatsApp.",
      heroImage1: "", heroImage2: "", address: "", hours: "", faqs: []
    },
    categories: [], products: [], promos: []
  };

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  let cache = null;
  let online = true;

  function normalize(d) {
    d = d || {};
    d.config = Object.assign({}, defaults.config, d.config || {});
    d.categories = Array.isArray(d.categories) ? d.categories : [];
    d.promos = Array.isArray(d.promos) ? d.promos : [];
    d.products = Array.isArray(d.products) ? d.products : [];
    return d;
  }
  function remember(d) { cache = normalize(d); try { localStorage.setItem(CACHE_KEY, JSON.stringify(cache)); } catch (e) {} }
  function fromBackup() { try { const d = JSON.parse(localStorage.getItem(CACHE_KEY)); if (d && Array.isArray(d.products)) return normalize(d); } catch (e) {} return null; }

  /* ---------- Cliente de la API ---------- */
  async function api(method, url, body) {
    const opt = { method, credentials: "same-origin", headers: {} };
    if (body !== undefined) { opt.headers["Content-Type"] = "application/json"; opt.body = JSON.stringify(body); }
    let res;
    try { res = await fetch(url, opt); }
    catch (e) { throw Object.assign(new Error("No hay conexión con el servidor. Revisa tu internet e inténtalo de nuevo."), { network: true }); }
    let data = null;
    try { data = await res.json(); } catch (e) {}
    if (!res.ok) throw Object.assign(new Error((data && data.error) || "No se pudo completar la acción."), { status: res.status });
    return data;
  }

  /* ---------- Carga de datos ---------- */
  async function refresh() {
    try {
      const d = await api("GET", "api/public");
      online = true; remember(d); return true;
    } catch (e) { online = false; return false; }
  }
  // El servidor inserta los datos en la página (carga instantánea y buena para Google).
  const ready = (async () => {
    if (window.__GM_DATA__) remember(window.__GM_DATA__);
    else if (!(await refresh())) cache = fromBackup() || clone(defaults);
  })();

  function load() { return clone(cache || defaults); }
  function isOnline() { return online; }

  /* ---------- Cambios en vivo ---------- */
  const listeners = new Set();
  let started = false, lastVersion = null, lastPoll = 0;
  async function check() {
    try {
      const v = (await api("GET", "api/version")).version;
      if (lastVersion === null) lastVersion = (cache && cache.version) || v;
      if (v !== lastVersion) { lastVersion = v; if (await refresh()) listeners.forEach(f => f()); }
    } catch (e) {}
  }
  function subscribe(fn) {
    listeners.add(fn);
    if (started) return;
    started = true;
    lastVersion = (cache && cache.version) || null;
    if ("EventSource" in window) {
      const es = new EventSource("api/events");
      es.addEventListener("update", () => check());
    }
    // Respaldo: por si la conexión en vivo se corta (redes móviles, proxys)
    setInterval(check, 30000);
    document.addEventListener("visibilitychange", () => { if (!document.hidden && Date.now() - lastPoll > 3000) { lastPoll = Date.now(); check(); } });
  }
  // El panel avisa aquí cuando él mismo cambió algo (para no esperar al evento)
  function adopt(d) { if (d && d.version) lastVersion = d.version; }

  /* ---------- Carrito (por visitante, en su navegador) ---------- */
  function loadCart() {
    try { return JSON.parse(localStorage.getItem(CART_KEY)) || {}; } catch (e) { return {}; }
  }
  function saveCart(cart) {
    try { localStorage.setItem(CART_KEY, JSON.stringify(cart)); } catch (e) {}
  }

  function money(n, cfg) { return (cfg ? cfg.currency : "S/") + " " + Number(n).toFixed(2); }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
    function initials(name) {
    return String(name || "GM").trim().split(/\s+/).slice(0, 2).map(w => w[0]).join("").toUpperCase() || "GM";
  }

  function today() {
    const d = new Date();
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  }
  function formatDate(iso) {
    if (!iso) return "";
    const [y, m, d] = iso.split("-");
    return d + "/" + m + "/" + y;
  }

  // Promociones vigentes: activas y que no hayan vencido
  function activePromos(data) {
    const t = today();
    return data.promos.filter(x => x.active && (!x.until || x.until >= t));
  }
  // Precio final de un producto con la mejor promoción que le corresponda
  function priceOf(p, data) {
    let best = 0;
    activePromos(data).forEach(x => {
      if (x.all || (x.productIds || []).includes(p.id)) best = Math.max(best, Number(x.percent) || 0);
    });
    return { percent: best, original: p.price, final: Math.round(p.price * (100 - best)) / 100 };
  }

  // Foto de portada: la que subió el encargado o la original del local
  function heroImg(data, n) {
    return data.config["heroImage" + n] || (n === 1 ? "img/local-1.jpg" : "img/local-2.jpg");
  }

  return { ready, load, refresh, isOnline, api, subscribe, adopt, normalize, loadCart, saveCart, money, esc, initials, defaults, today, formatDate, activePromos, priceOf, heroImg };
})();
