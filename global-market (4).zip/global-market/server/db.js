// Capa de base de datos (SQLite con better-sqlite3)
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const Database = require("better-sqlite3");
const { hashPassword } = require("./auth");

const ROOT = path.join(__dirname, "..");
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(ROOT, "data"));
const UPLOAD_DIR = path.join(DATA_DIR, "uploads");
const DB_FILE = path.join(DATA_DIR, "gm.sqlite");
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const db = new Database(DB_FILE);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

const read = f => fs.readFileSync(path.join(ROOT, "database", f), "utf8");

function init({ reset = false } = {}) {
  if (reset) {
    db.pragma("foreign_keys = OFF");
    ["promo_products", "promos", "products", "categories", "admin_user", "settings"].forEach(t => db.exec(`DROP TABLE IF EXISTS ${t}`));
    db.pragma("foreign_keys = ON");
  }
  db.exec(read("schema.sql"));
  const empty = db.prepare("SELECT COUNT(*) n FROM settings").get().n === 0;
  if (empty) {
    db.exec(read("seed.sql"));
    // Cuenta inicial personalizable desde variables de entorno (recomendado en producción)
    if (process.env.ADMIN_EMAIL || process.env.ADMIN_PASSWORD) {
      const u = db.prepare("SELECT email FROM admin_user WHERE id = 1").get();
      db.prepare("UPDATE admin_user SET email = ?, password_hash = ?, must_change = ? WHERE id = 1").run(
        (process.env.ADMIN_EMAIL || u.email).trim().toLowerCase(),
        process.env.ADMIN_PASSWORD ? hashPassword(process.env.ADMIN_PASSWORD) : db.prepare("SELECT password_hash h FROM admin_user WHERE id=1").get().h,
        process.env.ADMIN_PASSWORD ? 0 : 1
      );
    }
  }
  return empty;
}

/* ---------- Ajustes ---------- */
function settings() {
  const o = {};
  db.prepare("SELECT key, value FROM settings").all().forEach(r => { o[r.key] = r.value; });
  return o;
}
function setSetting(key, value) {
  db.prepare("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").run(key, String(value));
}
function sessionSecret() {
  if (process.env.SESSION_SECRET) return process.env.SESSION_SECRET;
  let s = settings().session_secret;
  if (!s) { s = crypto.randomBytes(32).toString("hex"); setSetting("session_secret", s); }
  return s;
}
function version() { return parseInt(settings().data_version, 10) || 1; }
function bump() {
  const v = version() + 1;
  setSetting("data_version", v);
  return v;
}

/* ---------- Lectura ---------- */
function config(admin) {
  const s = settings();
  let faqs = [];
  try { faqs = JSON.parse(s.faqs || "[]"); } catch (e) {}
  const c = {
    name: s.name, tagline: s.tagline, whatsapp: s.whatsapp, currency: s.currency,
    heroTitle: s.heroTitle, heroText: s.heroText, heroImage1: s.heroImage1 || "", heroImage2: s.heroImage2 || "",
    address: s.address || "", hours: s.hours || "", faqs
  };
  if (admin) {
    const u = db.prepare("SELECT email, must_change FROM admin_user WHERE id = 1").get();
    c.email = u.email; c.passwordSet = !u.must_change;
  }
  return c;
}
function categories() {
  return db.prepare("SELECT name FROM categories ORDER BY sort_order, id").all().map(r => r.name);
}
function products() {
  return db.prepare(`SELECT p.id, p.name, p.price, c.name AS category, p.description AS desc, p.image, p.stock
    FROM products p JOIN categories c ON c.id = p.category_id ORDER BY p.sort_order, p.rowid`).all();
}
function promos(onlyActive) {
  const links = {};
  db.prepare("SELECT promo_id, product_id FROM promo_products").all().forEach(r => { (links[r.promo_id] = links[r.promo_id] || []).push(r.product_id); });
  return db.prepare(`SELECT id, title, description AS desc, percent, all_products, until, image, active FROM promos
    ${onlyActive ? "WHERE active = 1" : ""} ORDER BY sort_order, rowid`).all()
    .map(p => ({ id: p.id, title: p.title, desc: p.desc, percent: p.percent, all: !!p.all_products, productIds: links[p.id] || [], until: p.until, image: p.image, active: !!p.active }));
}
function publicData() {
  return { version: version(), config: config(false), categories: categories(), products: products(), promos: promos(true) };
}
function adminData() {
  return { version: version(), config: config(true), categories: categories(), products: products(), promos: promos(false) };
}

/* ---------- Utilidades ---------- */
function newId(prefix) { return prefix + Date.now().toString(36) + crypto.randomBytes(2).toString("hex"); }
function minSort(table) { return (db.prepare(`SELECT MIN(sort_order) m FROM ${table}`).get().m ?? 0) - 1; }
function maxSort(table) { return (db.prepare(`SELECT MAX(sort_order) m FROM ${table}`).get().m ?? -1) + 1; }

/* ---------- Imágenes subidas ---------- */
const MAGIC = [
  ["png", b => b.slice(0, 4).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47]))],
  ["jpg", b => b[0] === 0xff && b[1] === 0xd8],
  ["webp", b => b.slice(0, 4).toString() === "RIFF" && b.slice(8, 12).toString() === "WEBP"],
  ["gif", b => b.slice(0, 3).toString() === "GIF"]
];
function saveImage(dataUrl) {
  const m = /^data:image\/(png|jpe?g|webp|gif);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl || "");
  if (!m) throw httpError(400, "La imagen no es válida (usa PNG, JPG o WEBP).");
  const buf = Buffer.from(m[2], "base64");
  if (buf.length > 6 * 1024 * 1024) throw httpError(413, "La imagen pesa demasiado (máximo 6 MB).");
  const kind = MAGIC.find(([, test]) => test(buf));
  if (!kind) throw httpError(400, "El archivo no parece una imagen válida.");
  const name = crypto.randomBytes(10).toString("hex") + "." + kind[0];
  fs.writeFileSync(path.join(UPLOAD_DIR, name), buf);
  return "uploads/" + name;
}
function removeUpload(p) {
  if (!/^uploads\/[a-f0-9]+\.(png|jpg|webp|gif)$/.test(p || "")) return;
  fs.rm(path.join(UPLOAD_DIR, path.basename(p)), { force: true }, () => {});
}
// Sólo se aceptan rutas conocidas o imágenes nuevas en base64
function resolveImage(value, keep) {
  if (value === undefined || value === null) return keep;
  if (typeof value !== "string") return keep;
  if (value.startsWith("data:image/")) return saveImage(value);
  if (/^(img|uploads)\/[\w\-./]+$/.test(value) && !value.includes("..")) return value;
  return keep;
}

function httpError(status, message) { const e = new Error(message); e.status = status; return e; }

module.exports = { db, init, DATA_DIR, UPLOAD_DIR, DB_FILE, settings, setSetting, sessionSecret, version, bump,
  config, categories, products, promos, publicData, adminData, newId, minSort, maxSort, saveImage, removeUpload, resolveImage, httpError };
