// Comandos de mantenimiento:  node server/cli.js init | reset | admin-reset
const D = require("./db");
const { hashPassword } = require("./auth");
const cmd = process.argv[2];

if (cmd === "init") {
  const created = D.init();
  console.log(created ? "Base de datos creada con los datos de prueba." : "La base de datos ya tenía datos; no se modificó nada.");
  console.log("Archivo:", D.DB_FILE);
} else if (cmd === "reset") {
  D.init({ reset: true });
  console.log("Base de datos reiniciada con los datos de prueba (productos, categorías y cuenta inicial).");
} else if (cmd === "admin-reset") {
  D.init();
  const email = (process.env.ADMIN_EMAIL || "admin@globalmarket.com").trim().toLowerCase();
  const pass = process.env.ADMIN_PASSWORD || "123456";
  D.db.prepare("UPDATE admin_user SET email = ?, password_hash = ?, must_change = ? WHERE id = 1").run(email, hashPassword(pass), process.env.ADMIN_PASSWORD ? 0 : 1);
  console.log(`Acceso restablecido.\n  Correo:     ${email}\n  Contraseña: ${process.env.ADMIN_PASSWORD ? "(la de ADMIN_PASSWORD)" : pass}`);
} else {
  console.log("Uso: npm run db:init | db:reset | admin:reset");
  process.exit(1);
}
