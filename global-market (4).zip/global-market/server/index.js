// Global Market — servidor (Express): sirve la tienda, el panel y la API
const path = require("path");
const fs = require("fs");
const express = require("express");
const compression = require("compression");
const D = require("./db");
const A = require("./auth");

const PORT = parseInt(process.env.PORT, 10) || 3000;
const PUBLIC = path.join(__dirname, "..", "public");
const PROD = process.env.NODE_ENV === "production";
const COOKIE = "gm_session";
const SESSION_MS = 7 * 24 * 3600 * 1000;

D.init();
const SECRET = D.sessionSecret();
const app = express();
app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use(compression({ filter: (req, res) => req.path !== "/api/events" && compression.filter(req, res) }));
app.use((req, res, next) => {
  res.set({ "X-Content-Type-Options": "nosniff", "Referrer-Policy": "strict-origin-when-cross-origin", "X-Frame-Options": "SAMEORIGIN" });
  next();
});
app.use(express.json({ limit: "14mb" }));

// Protección básica contra peticiones desde otros sitios: las que modifican datos deben ser JSON
app.use("/api", (req, res, next) => {
  if (!["GET", "HEAD", "OPTIONS"].includes(req.method) && !req.is("application/json") && req.method !== "DELETE") {
    return res.status(415).json({ error: "Formato no permitido." });
  }
  next();
});

/* ---------- Tiempo real (SSE) ---------- */
const clients = new Set();
function broadcast(v) { clients.forEach(res => res.write(`event: update\ndata: ${v}\n\n`)); }
app.get("/api/events", (req, res) => {
  res.set({ "Content-Type": "text/event-stream", "Cache-Control": "no-cache, no-transform", Connection: "keep-alive", "X-Accel-Buffering": "no" });
  res.flushHeaders();
  res.write(`retry: 3000\nevent: hello\ndata: ${D.version()}\n\n`);
  clients.add(res);
  req.on("close", () => clients.delete(res));
});
setInterval(() => clients.forEach(res => res.write(": ping\n\n")), 25000).unref();

/* ---------- API pública ---------- */
app.get("/api/public", (req, res) => {
  const etag = `W/"v${D.version()}"`;
  res.set({ ETag: etag, "Cache-Control": "no-cache" });
  if (req.get("If-None-Match") === etag) return res.status(304).end();
  res.json(D.publicData());
});
app.get("/api/version", (req, res) => res.set("Cache-Control", "no-store").json({ version: D.version() }));
app.get("/api/health", (req, res) => res.json({ ok: true, products: D.db.prepare("SELECT COUNT(*) n FROM products").get().n }));

/* ---------- Ingreso del encargado ---------- */
const attempts = new Map();
function limited(ip) {
  const a = attempts.get(ip);
  return a && a.reset > Date.now() && a.n >= 8;
}
function fail(ip) {
  const a = attempts.get(ip);
  if (!a || a.reset <= Date.now()) attempts.set(ip, { n: 1, reset: Date.now() + 15 * 60 * 1000 });
  else a.n++;
}
function pwTag(hash) { return require("crypto").createHash("sha256").update(hash).digest("hex").slice(0, 16); }
function setSession(req, res, user) {
  const token = A.createToken({ e: user.email, h: pwTag(user.password_hash) }, SECRET, SESSION_MS);
  res.cookie(COOKIE, token, { httpOnly: true, sameSite: "lax", secure: req.secure, maxAge: SESSION_MS, path: "/" });
}
const adminUser = () => D.db.prepare("SELECT email, password_hash, must_change FROM admin_user WHERE id = 1").get();

function auth(req, res, next) {
  const t = A.readToken(A.parseCookies(req.headers.cookie)[COOKIE], SECRET);
  const u = adminUser();
  if (!t || t.e !== u.email || t.h !== pwTag(u.password_hash)) return res.status(401).json({ error: "Tu sesión terminó. Vuelve a ingresar." });
  req.admin = u;
  next();
}

app.post("/api/login", (req, res) => {
  const ip = req.ip;
  if (limited(ip)) return res.status(429).json({ error: "Demasiados intentos. Espera unos minutos e inténtalo de nuevo." });
  const u = adminUser();
  const email = String((req.body || {}).email || "").trim().toLowerCase();
  const pass = String((req.body || {}).password || "");
  if (email === u.email.toLowerCase() && A.verifyPassword(pass, u.password_hash)) {
    attempts.delete(ip);
    setSession(req, res, u);
    return res.json({ ok: true, email: u.email, mustChange: !!u.must_change });
  }
  fail(ip);
  res.status(401).json({ error: "Correo o contraseña incorrectos. Inténtalo de nuevo." });
});
app.post("/api/logout", (req, res) => { res.clearCookie(COOKIE, { path: "/" }); res.json({ ok: true }); });
app.get("/api/me", auth, (req, res) => res.json({ email: req.admin.email, mustChange: !!req.admin.must_change }));

/* ---------- API del panel (requiere sesión) ---------- */
const admin = express.Router();
admin.use(auth);

const clean = (v, max) => String(v == null ? "" : v).trim().slice(0, max);
function done(res, status = 200) { const v = D.bump(); broadcast(v); res.status(status).json(D.adminData()); }
function categoryId(name) {
  const c = D.db.prepare("SELECT id FROM categories WHERE name = ?").get(clean(name, 80));
  if (!c) throw D.httpError(400, "La categoría elegida no existe.");
  return c.id;
}
function productFields(b) {
  const name = clean(b.name, 120);
  if (!name) throw D.httpError(400, "El producto necesita un nombre.");
  const price = Number(b.price);
  if (!isFinite(price) || price < 0 || price > 1e6) throw D.httpError(400, "El precio no es válido.");
  return { name, price: Math.round(price * 100) / 100, cat: categoryId(b.category), desc: clean(b.desc, 600), stock: Math.max(0, Math.min(1e6, parseInt(b.stock, 10) || 0)) };
}

admin.get("/data", (req, res) => res.set("Cache-Control", "no-store").json(D.adminData()));

// Productos
admin.post("/products", (req, res) => {
  const f = productFields(req.body || {});
  const image = D.resolveImage(req.body.image, "");
  D.db.prepare("INSERT INTO products (id, name, price, category_id, description, image, stock, sort_order) VALUES (?,?,?,?,?,?,?,?)")
    .run(D.newId("p"), f.name, f.price, f.cat, f.desc, image, f.stock, D.minSort("products"));
  done(res, 201);
});
admin.put("/products/:id", (req, res) => {
  const old = D.db.prepare("SELECT image FROM products WHERE id = ?").get(req.params.id);
  if (!old) throw D.httpError(404, "El producto ya no existe.");
  const f = productFields(req.body || {});
  const image = D.resolveImage(req.body.image || undefined, old.image);
  D.db.prepare("UPDATE products SET name=?, price=?, category_id=?, description=?, image=?, stock=?, updated_at=datetime('now') WHERE id=?")
    .run(f.name, f.price, f.cat, f.desc, image, f.stock, req.params.id);
  if (image !== old.image) D.removeUpload(old.image);
  done(res);
});
admin.patch("/products/:id/stock", (req, res) => {
  const r = D.db.prepare("UPDATE products SET stock=?, updated_at=datetime('now') WHERE id=?")
    .run(Math.max(0, Math.min(1e6, parseInt((req.body || {}).stock, 10) || 0)), req.params.id);
  if (!r.changes) throw D.httpError(404, "El producto ya no existe.");
  done(res);
});
admin.delete("/products/:id", (req, res) => {
  const old = D.db.prepare("SELECT image FROM products WHERE id = ?").get(req.params.id);
  if (old) { D.db.prepare("DELETE FROM products WHERE id = ?").run(req.params.id); D.removeUpload(old.image); }
  done(res);
});

// Promociones
function promoFields(b) {
  const title = clean(b.title, 120);
  if (!title) throw D.httpError(400, "La promoción necesita un título.");
  const until = clean(b.until, 10);
  if (until && !/^\d{4}-\d{2}-\d{2}$/.test(until)) throw D.httpError(400, "La fecha no es válida.");
  const all = b.all !== false;
  const ids = all ? [] : (Array.isArray(b.productIds) ? b.productIds : []).map(String);
  if (!all && !ids.length) throw D.httpError(400, "Elige al menos un producto para la promoción.");
  return { title, desc: clean(b.desc, 300), percent: Math.min(90, Math.max(1, parseInt(b.percent, 10) || 1)), all, ids, until, active: b.active !== false };
}
function linkPromo(id, ids) {
  D.db.prepare("DELETE FROM promo_products WHERE promo_id = ?").run(id);
  const ins = D.db.prepare("INSERT OR IGNORE INTO promo_products (promo_id, product_id) SELECT ?, id FROM products WHERE id = ?");
  ids.forEach(p => ins.run(id, p));
}
admin.post("/promos", (req, res) => {
  const f = promoFields(req.body || {});
  const id = D.newId("pr");
  D.db.transaction(() => {
    D.db.prepare("INSERT INTO promos (id, title, description, percent, all_products, until, image, active, sort_order) VALUES (?,?,?,?,?,?,?,?,?)")
      .run(id, f.title, f.desc, f.percent, f.all ? 1 : 0, f.until, D.resolveImage(req.body.image, ""), f.active ? 1 : 0, D.minSort("promos"));
    linkPromo(id, f.ids);
  })();
  done(res, 201);
});
admin.put("/promos/:id", (req, res) => {
  const old = D.db.prepare("SELECT image FROM promos WHERE id = ?").get(req.params.id);
  if (!old) throw D.httpError(404, "La promoción ya no existe.");
  const f = promoFields(req.body || {});
  const image = D.resolveImage(req.body.image || undefined, old.image);
  D.db.transaction(() => {
    D.db.prepare("UPDATE promos SET title=?, description=?, percent=?, all_products=?, until=?, image=?, active=? WHERE id=?")
      .run(f.title, f.desc, f.percent, f.all ? 1 : 0, f.until, image, f.active ? 1 : 0, req.params.id);
    linkPromo(req.params.id, f.ids);
  })();
  if (image !== old.image) D.removeUpload(old.image);
  done(res);
});
admin.patch("/promos/:id/toggle", (req, res) => {
  const r = D.db.prepare("UPDATE promos SET active = 1 - active WHERE id = ?").run(req.params.id);
  if (!r.changes) throw D.httpError(404, "La promoción ya no existe.");
  done(res);
});
admin.delete("/promos/:id", (req, res) => {
  const old = D.db.prepare("SELECT image FROM promos WHERE id = ?").get(req.params.id);
  if (old) { D.db.prepare("DELETE FROM promos WHERE id = ?").run(req.params.id); D.removeUpload(old.image); }
  done(res);
});

// Categorías
admin.post("/categories", (req, res) => {
  const name = clean((req.body || {}).name, 80);
  if (!name) throw D.httpError(400, "Escribe el nombre de la categoría.");
  if (D.db.prepare("SELECT 1 FROM categories WHERE name = ?").get(name)) throw D.httpError(409, "Esa categoría ya existe.");
  D.db.prepare("INSERT INTO categories (name, sort_order) VALUES (?, ?)").run(name, D.maxSort("categories"));
  done(res, 201);
});
admin.put("/categories", (req, res) => {
  const from = clean((req.body || {}).from, 80), to = clean((req.body || {}).to, 80);
  if (!to) throw D.httpError(400, "Escribe el nuevo nombre.");
  const c = D.db.prepare("SELECT id FROM categories WHERE name = ?").get(from);
  if (!c) throw D.httpError(404, "La categoría ya no existe.");
  const dup = D.db.prepare("SELECT id FROM categories WHERE name = ?").get(to);
  if (dup && dup.id !== c.id) throw D.httpError(409, "Esa categoría ya existe.");
  D.db.prepare("UPDATE categories SET name = ? WHERE id = ?").run(to, c.id);
  done(res);
});
admin.delete("/categories", (req, res) => {
  const c = D.db.prepare("SELECT id FROM categories WHERE name = ?").get(clean(req.query.name, 80));
  if (!c) return done(res);
  if (D.db.prepare("SELECT 1 FROM products WHERE category_id = ?").get(c.id)) throw D.httpError(409, "Mueve o elimina primero los productos de esta categoría.");
  D.db.prepare("DELETE FROM categories WHERE id = ?").run(c.id);
  done(res);
});

// Datos de la tienda y portada
admin.put("/config", (req, res) => {
  const b = req.body || {}, s = D.settings();
  const set = (k, v) => D.setSetting(k, v);
  D.db.transaction(() => {
    if (b.name !== undefined) { const n = clean(b.name, 80); if (!n) throw D.httpError(400, "El nombre de la tienda no puede estar vacío."); set("name", n); }
    if (b.tagline !== undefined) set("tagline", clean(b.tagline, 120));
    if (b.whatsapp !== undefined) set("whatsapp", String(b.whatsapp).replace(/\D/g, "").slice(0, 15));
    if (b.currency !== undefined) set("currency", clean(b.currency, 6) || "S/");
    if (b.address !== undefined) set("address", clean(b.address, 200));
    if (b.hours !== undefined) set("hours", clean(b.hours, 200));
    if (b.heroTitle !== undefined) set("heroTitle", clean(b.heroTitle, 140));
    if (b.heroText !== undefined) set("heroText", clean(b.heroText, 400));
    if (Array.isArray(b.faqs)) set("faqs", JSON.stringify(b.faqs.slice(0, 30).map(f => ({ q: clean(f.q, 200), a: clean(f.a, 800) })).filter(f => f.q && f.a)));
    [1, 2].forEach(n => {
      const k = "heroImage" + n;
      if (b[k] === undefined) return;
      const next = b[k] === "" ? "" : D.resolveImage(b[k], s[k] || "");
      if (next !== (s[k] || "")) { D.removeUpload(s[k]); set(k, next); }
    });
  })();
  done(res);
});
admin.put("/account", (req, res) => {
  const b = req.body || {};
  const email = clean(b.email, 120).toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw D.httpError(400, "Escribe un correo válido.");
  const pass = String(b.password || "");
  if (pass && pass.length < 6) throw D.httpError(400, "La contraseña debe tener al menos 6 caracteres.");
  if (pass) D.db.prepare("UPDATE admin_user SET email=?, password_hash=?, must_change=0, updated_at=datetime('now') WHERE id=1").run(email, A.hashPassword(pass));
  else D.db.prepare("UPDATE admin_user SET email=?, updated_at=datetime('now') WHERE id=1").run(email);
  setSession(req, res, adminUser());
  done(res);
});

// Copia de seguridad
admin.get("/export", (req, res) => {
  const d = D.adminData();
  delete d.config.email; delete d.config.passwordSet; delete d.version;
  res.set("Content-Disposition", 'attachment; filename="global-market-copia.json"').json(d);
});
admin.post("/import", (req, res) => {
  const d = req.body || {};
  if (!Array.isArray(d.products) || !Array.isArray(d.categories)) throw D.httpError(400, "El archivo no es una copia válida.");
  D.db.transaction(() => {
    D.db.prepare("DELETE FROM promo_products").run();
    D.db.prepare("DELETE FROM promos").run();
    D.db.prepare("DELETE FROM products").run();
    D.db.prepare("DELETE FROM categories").run();
    const cats = [...new Set(d.categories.map(c => clean(c, 80)).filter(Boolean))];
    d.products.forEach(p => { const c = clean(p.category, 80); if (c && !cats.includes(c)) cats.push(c); });
    const insCat = D.db.prepare("INSERT INTO categories (name, sort_order) VALUES (?, ?)");
    cats.forEach((c, i) => insCat.run(c, i));
    const insP = D.db.prepare("INSERT INTO products (id, name, price, category_id, description, image, stock, sort_order) VALUES (?,?,?,?,?,?,?,?)");
    const ids = new Set();
    d.products.forEach((p, i) => {
      if (!clean(p.name, 120)) return;
      let id = clean(p.id, 40).replace(/[^\w-]/g, "") || D.newId("p");
      if (ids.has(id)) id = D.newId("p");
      ids.add(id);
      insP.run(id, clean(p.name, 120), Math.max(0, Number(p.price) || 0), categoryId(p.category), clean(p.desc, 600), D.resolveImage(p.image, ""), Math.max(0, parseInt(p.stock, 10) || 0), i);
    });
    (Array.isArray(d.promos) ? d.promos : []).forEach((x, i) => {
      if (!clean(x.title, 120)) return;
      const id = clean(x.id, 40).replace(/[^\w-]/g, "") || D.newId("pr");
      D.db.prepare("INSERT OR REPLACE INTO promos (id, title, description, percent, all_products, until, image, active, sort_order) VALUES (?,?,?,?,?,?,?,?,?)")
        .run(id, clean(x.title, 120), clean(x.desc, 300), Math.min(90, Math.max(1, parseInt(x.percent, 10) || 1)), x.all === false ? 0 : 1, /^\d{4}-\d{2}-\d{2}$/.test(x.until || "") ? x.until : "", D.resolveImage(x.image, ""), x.active === false ? 0 : 1, i);
      linkPromo(id, x.all === false ? (x.productIds || []).map(String) : []);
    });
    const c = d.config || {};
    ["name", "tagline", "currency", "address", "hours", "heroTitle", "heroText"].forEach(k => { if (typeof c[k] === "string" && (k !== "name" || c[k].trim())) D.setSetting(k, clean(c[k], 400)); });
    if (c.whatsapp) D.setSetting("whatsapp", String(c.whatsapp).replace(/\D/g, "").slice(0, 15));
    if (Array.isArray(c.faqs)) D.setSetting("faqs", JSON.stringify(c.faqs.slice(0, 30).map(f => ({ q: clean(f.q, 200), a: clean(f.a, 800) })).filter(f => f.q && f.a)));
  })();
  done(res);
});

app.use("/api/admin", admin);
app.use("/api", (req, res) => res.status(404).json({ error: "No encontrado." }));

/* ---------- Páginas y archivos ---------- */
const baseUrl = req => (process.env.SITE_URL || `${req.protocol}://${req.get("host")}`).replace(/\/+$/, "");
const jsonForHtml = o => JSON.stringify(o).replace(/</g, "\\u003c").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
const escAttr = s => String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");

let tpl = { html: "", mtime: 0 };
function template() {
  const f = path.join(PUBLIC, "index.html");
  const m = fs.statSync(f).mtimeMs;
  if (m !== tpl.mtime) tpl = { html: fs.readFileSync(f, "utf8"), mtime: m };
  return tpl.html;
}
function renderIndex(req) {
  const data = D.publicData(), c = data.config, base = baseUrl(req);
  const items = data.products.filter(p => p.stock > 0).slice(0, 100).map((p, i) => ({
    "@type": "ListItem", position: i + 1,
    item: { "@type": "Product", name: p.name, description: p.desc, image: `${base}/${p.image || "img/logo.png"}`, category: p.category,
      offers: { "@type": "Offer", price: p.price.toFixed(2), priceCurrency: "PEN", availability: "https://schema.org/InStock", url: base + "/" } }
  }));
  const store = { "@context": "https://schema.org", "@type": "Store", name: c.name, description: c.tagline, url: base + "/", logo: `${base}/img/logo.png`, image: `${base}/img/local-1.jpg`, priceRange: "$" };
  if (c.address) store.address = c.address;
  const list = { "@context": "https://schema.org", "@type": "ItemList", name: `Catálogo de ${c.name}`, itemListElement: items };
  let html = template()
    .replace(/https:\/\/TU-DOMINIO\.com/g, base)
    .replace(/<script type="application\/ld\+json">[\s\S]*?<\/script>/, `<script type="application/ld+json">${jsonForHtml(store)}</script>\n  <script type="application/ld+json">${jsonForHtml(list)}</script>`)
    .replace(/<title>[\s\S]*?<\/title>/, `<title>${escAttr(c.name)} | ${escAttr(c.tagline || "Catálogo")}</title>`)
    .replace("</head>", `  <script>window.__GM_DATA__=${jsonForHtml(data)};</script>\n</head>`);
  return html;
}
app.get(["/", "/index.html"], (req, res) => { res.set("Cache-Control", "no-cache").type("html").send(renderIndex(req)); });
app.get(["/admin", "/admin.html"], (req, res) => { res.set({ "Cache-Control": "no-store", "X-Robots-Tag": "noindex, nofollow" }).sendFile(path.join(PUBLIC, "admin.html")); });
app.get("/robots.txt", (req, res) => res.type("text/plain").send(`User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /admin.html\nDisallow: /api/\n\nSitemap: ${baseUrl(req)}/sitemap.xml\n`));
app.get("/sitemap.xml", (req, res) => res.type("application/xml").send(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>${baseUrl(req)}/</loc><lastmod>${new Date().toISOString().slice(0, 10)}</lastmod><changefreq>daily</changefreq><priority>1.0</priority></url>\n</urlset>\n`));

app.use("/uploads", express.static(D.UPLOAD_DIR, { maxAge: "30d", immutable: true, index: false, fallthrough: false }));
app.use(express.static(PUBLIC, { maxAge: PROD ? "1h" : 0, index: false, extensions: [] }));

app.use((req, res) => res.status(404).type("text/plain").send("Página no encontrada"));
app.use((err, req, res, next) => {
  if (err.type === "entity.too.large") err = D.httpError(413, "Los datos enviados son demasiado grandes.");
  const status = err.status || (err.code === "SQLITE_CONSTRAINT_FOREIGNKEY" ? 409 : 500);
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 ? "Ocurrió un error en el servidor." : err.message });
});

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Global Market listo en http://localhost:${PORT}`);
    console.log(`  Tienda:  http://localhost:${PORT}/\n  Panel:   http://localhost:${PORT}/admin`);
    if (PROD && !process.env.ADMIN_PASSWORD && adminUser().must_change) console.warn("AVISO: sigues usando la contraseña inicial. Define ADMIN_PASSWORD o cámbiala al entrar al panel.");
  });
}
module.exports = app;
